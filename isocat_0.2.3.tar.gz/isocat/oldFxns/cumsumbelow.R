#'
#' Function that calculates the cumulative sum of values less than or equal to a given value.
#'
#' @param vals Object of numeric or integer class.
#'
#' @return Returns list of values representing cumulative sum of `val` values less than or equal to the input.
#'
#'
#' @examples
#' vals <- 1:10
#' cumsumbelow(vals)
#'
#' @export
cumsumbelow <- function(vals){
  if(class(vals) != "numeric" & class(vals) != "integer") stop("values entered must be numeric")
  vals %>% purrr::map(~ vals[ vals <= . ] %>% sum(na.rm = T) )
}
